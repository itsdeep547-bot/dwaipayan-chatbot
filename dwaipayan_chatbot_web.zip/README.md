# Dwaipayan's AI Assistant

A public web chatbot with:
- Calculator (safe evaluation)
- Unit conversion (Pint)
- Wikipedia summaries
- Weather via Open-Meteo (free, no API key)

## How to Deploy to Streamlit Cloud
1. Push these files to a GitHub repository.
2. Go to https://streamlit.io/cloud and sign in with GitHub.
3. Click "New App", choose your repo, select `app.py`, and deploy.
4. Share your public link!
